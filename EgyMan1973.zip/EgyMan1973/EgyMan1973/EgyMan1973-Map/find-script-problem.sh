figlet find problem
echo " "
read -p "Target: " t
read -p "RND: " r
nmap -D RND:$r --script exploit -script-trace $t

