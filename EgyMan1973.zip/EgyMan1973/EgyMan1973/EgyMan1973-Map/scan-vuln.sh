figlet scan vuln
echo " "
read -p "Target: " t
read -p "RND: " r
nmap -D RND:$r --script vuln $t

