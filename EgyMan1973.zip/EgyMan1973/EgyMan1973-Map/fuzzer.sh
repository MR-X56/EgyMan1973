figlet Fuzz
echo " "
echo "levels: [0, 1, 2, 3, 4, 5]"
read -p "Target: " t
read -p "level: " l
nmap -T$l -sU --script dns-fuzz --script-args timelimit=2h $t
nmap -T$l --script http-form-fuzzer --script-args 'http-form-fuzzer.targets={1={path=/},2={path=/register.html}}' -p 80 $t
nmap -T$l -sV --script=http-self-xss $t

