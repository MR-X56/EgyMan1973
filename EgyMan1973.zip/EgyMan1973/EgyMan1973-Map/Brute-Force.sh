figlet Brute-force
echo " "
echo "levels: [0, 1, 2, 3, 4, 5]"
read -p "port: " p
read -p "target: " t
read -p "level: " l
echo " "
nmap -T$l -p$p --script http-enum $t

