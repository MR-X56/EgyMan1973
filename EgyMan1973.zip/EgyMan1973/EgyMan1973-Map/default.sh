figlet default scan
echo " "
echo "levels: [0, 1, 2, 3, 4, 5]"
read -p "Target: " t
read -p "port: " p
read -p "level: " l
nmap -T$l -v -p $p $t
nmap -T$l $t -A
nmap -T$l -O $t
nmap -T$l -sV $t
nmap -T$l -F $t
nmap -T$l -p 21,80,139,55,66,11,88,8080,443,4444,36,37,38,39,40,1000,5000,50,49,12,13,14,15,16,17,18 $t
nmap -T$l -sU $t
nmap -T$l -sN $t


