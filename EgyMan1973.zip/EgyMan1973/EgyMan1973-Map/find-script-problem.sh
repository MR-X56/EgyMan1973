figlet find problem
echo " "
echo "levels: [0, 1, 2, 3, 4, 5]"
read -p "Target: " t
read -p "level: " l
nmap -T$l --script exploit -script-trace $t

